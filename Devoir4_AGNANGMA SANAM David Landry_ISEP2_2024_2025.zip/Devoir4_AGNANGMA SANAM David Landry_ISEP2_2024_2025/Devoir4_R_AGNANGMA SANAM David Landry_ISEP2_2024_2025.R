
#### Devoir 4 R


#############################
### DEVOIR R - ANALYSE DES MÉNAGES ###
#############################

library(haven)
library(dplyr)


# Chargement des données
data_s01 <- read_dta("s01_me_SEN2018.dta")
data_s02 <- read_dta("s02_me_SEN2018.dta")
data_s03 <- read_dta("s03_me_SEN2018.dta")
data_s04 <- read_dta("s04_me_SEN2018.dta")




#------------------------------------------------------------------
# 1. Taille et composition des ménages
#------------------------------------------------------------------
# Taille moyenne des ménages

# → Analyser la taille moyenne des ménages et la structure par âge/genre.



data_s01 <- data_s01 %>%
  mutate(id_menage = paste(grappe, menage, sep = "_"))

# Afficher la nouvelle colonne
print(data_s01$id_menage)

# Calcul et affichage de la taille moyenne des ménages
library(dplyr)

# Calcul du nombre total d'individus
total_individus <- nrow(data_s01)

# Calcul du nombre total de ménages
total_menages <- data_s01 %>%
  distinct(id_menage) %>%
  nrow()

# Taille moyenne des ménages
taille_moyenne <- total_individus / total_menages

# Affichage
cat("La taille moyenne des ménages est de :", round(taille_moyenne, 2), "\n")
# Resultat : La taille moyenne des ménages est de : 9.24 

# Structure des ménages par sexe

library(dplyr)

# Étape 1 : Nombre d'hommes et de femmes par ménage
structure_par_menage <- data_s01 %>%
  group_by(id_menage, s01q01) %>%
  summarise(nombre = n(), .groups = "drop")

# Étape 2 : Moyenne par sexe sur tous les ménages
moyenne_par_sexe <- structure_par_menage %>%
  group_by(s01q01) %>%
  summarise(moyenne_par_menage = mean(nombre))

# Affichage
print(moyenne_par_sexe)

#s01q01           moyenne_par_menage
#<dbl+lbl>                     <dbl>
#  1     1 [Masculin]               4.44
#2     2 [Féminin]                5.18
#3 NA(a)                          1 

# Structure des ménages par age

data_s01 <- data_s01 %>%
  mutate(
    age = 2025 - s01q03c
  )

# Créer les classes d’âge simples (si pas encore faites)
data_s01 <- data_s01 %>%
  mutate(classe_age_simple = case_when(
    age >= 0 & age <= 14 ~ "Enfant",
    age >= 15 & age <= 24 ~ "Jeune",
    age >= 25 & age <= 59 ~ "Adulte",
    age >= 60            ~ "Senior",
    TRUE                 ~ NA_character_
  ))

# Nombre d'individus par classe d'âge et par ménage
age_par_menage <- data_s01 %>%
  group_by(id_menage, classe_age_simple) %>%
  summarise(n = n(), .groups = "drop")

# Moyenne par classe d’âge sur tous les ménages
moyenne_age_par_menage <- age_par_menage %>%
  group_by(classe_age_simple) %>%
  summarise(moyenne = mean(n))

# Affichage
print(moyenne_age_par_menage)



#------------------------------------------------------------------
# 2. Taux d'alphabétisation (3 ans et plus)
#------------------------------------------------------------------

# → Calculer le pourcentage d’individus alphabétisés (3 ans et plus).

data_s02 <- read_dta("C:/Users/T Informatique/Desktop/Langage R/Projet EHCVM/SEN2018_menage/s02_me_SEN2018.dta")
View(data_s02)

var_labels <- sapply(data_s02, attr, "label")

# Mettre sous forme de data frame
df_labels <- data.frame(
  variable = names(var_labels),
  label = unname(var_labels),
  row.names = NULL,
  stringsAsFactors = FALSE
)

print(df_labels)


library(dplyr)

# Créer la variable alphabete_plus_3 directement dans data_s02
library(dplyr)

# Si age n'est pas encore dans data_s02, tu peux l'ajouter ici
data_s02 <- data_s02 %>%
  mutate(
    alphabete_plus_3 = ifelse(
      # Vérifier si au moins une des variables de lecture ou d'écriture est égale à 1
      s02q01_1 == 1 | s02q012 == 1 | s02q013 == 1 | s02q021 == 1 | s02q02_2 == 1, 
      1, 0
    )
  )

# Affichage pour vérifier le résultat
head(data_s02)



# Affichage des premières lignes pour vérifier
head(data_s01)


#------------------------------------------------------------------
# 3. Niveau d'éducation atteint (par tranche d'âge)
#------------------------------------------------------------------
education_tranche_age <- data_s02 %>%
  mutate(
    tranche_age = cut(s01q04a, breaks = c(0, 15, 30, 45, 60, 100))
  ) %>%
  count(tranche_age, s02q29) %>%  # s02q29 = niveau d'études le plus élevé
  group_by(tranche_age) %>%
  mutate(pourcentage = n / sum(n) * 100)

#------------------------------------------------------------------
# 4. Accès aux soins de santé
#------------------------------------------------------------------
acces_soins <- data_s02 %>%
  filter(s02q17 == 1) %>%
  summarise(
    taux_consult = mean(s02q22 == 1, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 5. Taux d'emploi (15-64 ans)
#------------------------------------------------------------------
emploi <- data_s02 %>%
  filter(s01q04a >= 15 & s01q04a <= 64) %>%
  summarise(
    emploi_principal = mean(s02q21= 1, na.rm = TRUE),  # À adapter
    emploi_secondaire = mean(s02q12 1, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 6. Activités génératrices de revenus hors emploi
#------------------------------------------------------------------
# Exemple avec variables hypothétiques :
revenus_hors_emploi <- data_s01 %>%
  summarise(
    location = mean(s01q01= 1, na.rm = TRUE),  # À adapter
    transferts = mean(s01q15= 1, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 7. Accès au crédit
#------------------------------------------------------------------
acces_credit <- data_s01 %>%
  summarise(
    taux = mean(s01q301, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 8. Consommation alimentaire (repas à l'extérieur)
#------------------------------------------------------------------
consommation_alim <- data_s01 %>%
  group_by(menage) %>%
  summarise(
    moy_repas_ext = mean(s01q, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 9. Dépenses alimentaires hebdomadaires
#------------------------------------------------------------------
depenses_alim <- data_s01 %>%
  summarise(
    depense_moy = mean(s01q38, na.rm = TRUE)  # s01q38 = dépenses
  )

#------------------------------------------------------------------
# 10. Indice de sécurité alimentaire (FIES)
#------------------------------------------------------------------
fies_score <- data_s01 %>%
  rowwise() %>%
  mutate(
    fies = sum(c_across(starts_with("FIES")), na.rm = TRUE)
  )

#------------------------------------------------------------------
# 11. Transferts reçus
#------------------------------------------------------------------
transferts <- data_s01 %>%
  summarise(
    transfert_prive = mean(s01qEE == 1, na.rm = TRUE),
    aide_sociale = mean(s01qFF == 1, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 12. Chocs économiques récents
#------------------------------------------------------------------
chocs <- data_s01 %>%
  summarise(
    taux_chocs = mean(s01qGG == 1, na.rm = TRUE)
  )

#------------------------------------------------------------------
# 13. Stratégies de survie post-COVID
#------------------------------------------------------------------
strategies <- data_s01 %>%
  summarise(
    across(starts_with("s01qHH"), ~mean(. == 1, na.rm = TRUE)
    )
    
    #------------------------------------------------------------------
    # 14. Entreprises non agricoles
    #------------------------------------------------------------------
    entreprises <- data_s01 %>%
      summarise(
        proportion = mean(s01qII == 1, na.rm = TRUE)
      )
    
    #------------------------------------------------------------------
    # 15. Équipements agricoles
    #------------------------------------------------------------------
    equipements <- data_s01 %>%
      summarise(
        across(c(s01qJJ1, s01qJJ2), ~mean(. == 1, na.rm = TRUE))
      )
    
    #------------------------------------------------------------------
    # 16. Élevage
    #------------------------------------------------------------------
    elevage <- data_s01 %>%
      summarise(
        across(starts_with("s01qKK"), ~mean(., na.rm = TRUE)) 
      )
    
    #------------------------------------------------------------------
    # 17. Pauvreté subjective
    #------------------------------------------------------------------
    pauvrete <- data_s01 %>%
      group_by(quintile) %>%
      summarise(
        pauvrete_ressentie = mean(s01qLL == 1, na.rm = TRUE)
      )
    
    #############################
    ### FIN DU SCRIPT ###
    #############################



