options(encoding = "UTF-8")


# Définir le chemin d'accès vers "EXPOSE_David Landry SANAM" dans votre PC

setwd("C:/Users/DAVID/Desktop/PARCOURS ISE/ISEP/ISEP2_2024_2025/SEMESTRE 2/INFORMATIQUE/PROGRAMMATION AVEC R/ISEP2025/ISEP2025/EXPOSE_David Landry SANAM")


# Liste des packages nécessaires
packages <- c("tidyverse", "haven", "labelled", "ggplot2", "forcats", "scales", "viridis", "RColorBrewer", "lsr")

# Fonction d'installation si le package est manquant
install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg)
  }
}

# Installer les packages manquants
invisible(lapply(packages, install_if_missing))

# Charger les packages
lapply(packages, library, character.only = TRUE)


# Chargement des données

s00 <- read_dta("s00_me_SEN2018.dta")  # Caractéristiques de l'enquete
s01 <- read_dta("s01_me_SEN2018.dta")  # Caractéristiques sociodémographiques
s02 <- read_dta("s02_me_SEN2018.dta")  # Éducation
s04 <- read_dta("s04_me_SEN2018.dta")  # Emploi


# 2. Extraire la date d’interview
s00 <- s00 %>%
  mutate(date_interview = as.Date(substr(s00q23a, 1, 10))) %>%
  select(vague, grappe, menage, date_interview)


# 3. Joindre la date d’interview à la base des individus (s01)
s01 <- s01 %>%
  left_join(s00, by = c("vague", "grappe", "menage"))


# Création de l'identifiant unique dans chaque base
s01 <- s01 %>% mutate(id_ind = paste(vague, grappe, menage, s01q00a, sep = "_"))
s02 <- s02 %>% mutate(id_ind = paste(vague, grappe, menage, s01q00a, sep = "_"))
s04 <- s04 %>% mutate(id_ind = paste(vague, grappe, menage, s01q00a, sep = "_"))




# 4. Créer la date de naissance (si année/mois/jour valides)
s01 <- s01 %>%
  mutate(date_naissance = case_when(
    !is.na(s01q03c) & s01q03c < 9999 &
      !is.na(s01q03b) & s01q03b <= 12 &
      !is.na(s01q03a) & s01q03a <= 31 ~
      as.Date(sprintf("%04d-%02d-%02d", s01q03c, s01q03b, s01q03a)),
    TRUE ~ NA_Date_
  ))

# 5. Calculer l'âge en priorité avec la date de naissance
s01 <- s01 %>%
  mutate(age = case_when(
    !is.na(date_naissance) & !is.na(date_interview) ~
      floor(as.numeric(difftime(date_interview, date_naissance, units = "days")) / 365.25),
    is.na(date_naissance) & !is.na(s01q04a) ~ s01q04a,  # âge déclaré en années
    is.na(date_naissance) & is.na(s01q04a) & !is.na(s01q04b) ~ s01q04b,  # âge en mois si jeune enfant
    TRUE ~ NA_real_
  ))


# Fusion des bases de données
individus <- s01 %>%
  left_join(s02, by = "id_ind") %>%
  left_join(s04, by = "id_ind")

# Filtrage des individus âgés de plus de 5 ans
individus <- individus %>% filter(age > 5)

# Remplacement des valeurs spécifiques
individus <- individus %>%
  mutate(
    annee_derniere_scolarisation = ifelse(s02q32 == 9999, NA, s02q32),
    diplome_obtenu = ifelse(s02q33 == 0, NA, s02q33)
  )

# Création de l'indicateur "est_diplome"
individus <- individus %>%
  mutate(est_diplome = case_when(
    s02q03 == 2 ~ "Jamais scolarisé",
    is.na(s02q33) | s02q33 == 0 ~ "Sans diplôme",
    TRUE ~ "Avec diplôme"
  ))

# Création du niveau d'éducation détaillé
individus <- individus %>%
  mutate(niveau_educatif_diplome = case_when(
    s02q03 == 2 ~ "Jamais scolarisé",
    s02q03 == 1 & is.na(s02q29) ~ "Scolarisé non renseigné",
    s02q29 %in% c(1, 2) & s02q33 != 0 ~ "Primaire diplômé",
    s02q29 %in% c(1, 2) & s02q33 == 0 ~ "Primaire sans diplôme",
    s02q29 %in% 3:6 & s02q33 != 0 ~ "Secondaire diplômé",
    s02q29 %in% 3:6 & s02q33 == 0 ~ "Secondaire sans diplôme",
    s02q29 %in% 7:8 ~ "Supérieur",
    TRUE ~ NA_character_
  ))

# Détermination du statut d’emploi
individus <- individus %>%
  mutate(
    actif_occupe = if_else(
      s04q06 == 1 | s04q07 == 1 | s04q08 == 1 | s04q09 == 1 | s04q11 == 1,
      TRUE, FALSE, missing = FALSE
    ),
    statut_emploi = case_when(
      actif_occupe ~ "Actif occupé",
      !actif_occupe & s04q17 == 1 ~ "Chômeur",
      !actif_occupe & s04q17 == 2 ~ "Inactif",
      TRUE ~ NA_character_
    )
  )

# Mise en facteur ordonnée
individus$statut_emploi <- factor(individus$statut_emploi,
                                  levels = c("Inactif", "Chômeur", "Actif occupé"),
                                  ordered = TRUE)

# Création de la catégorie socioprofessionnelle
individus <- individus %>%
  mutate(categorie_socioprofessionnelle = case_when(
    s04q39 == 1 ~ "Cadre supérieur",
    s04q39 == 2 ~ "Cadre moyen",
    s04q39 %in% c(3, 4) ~ "Ouvrier / Employé",
    s04q39 %in% c(5, 8) ~ "Travailleur non rémunéré / Aide",
    s04q39 %in% c(6, 7) ~ "Stagiaire / Apprenti",
    s04q39 == 9 ~ "Travailleur indépendant",
    s04q39 == 10 ~ "Patron",
    TRUE ~ NA_character_
  ))

# Filtrage des individus en emploi avec CSP renseignée
individus_csp <- individus %>%
  filter(statut_emploi == "Actif occupé", !is.na(categorie_socioprofessionnelle))


# Suppression des observations manquantes
individus <- individus %>%
  filter(!is.na(niveau_educatif_diplome), !is.na(statut_emploi))

# Graphique de répartition

# Résultat 1 : Répartition selon le statut d'emploi


library(ggplot2)
library(scales)  # pour percent()

# Création du diagramme en secteurs
p <- ggplot(individus, aes(x = "", fill = statut_emploi)) +
  geom_bar(width = 1, stat = "count") +
  coord_polar("y", start = 0) +
  geom_text(
    aes(
      label = scales::percent(..count.. / sum(..count..)),
      y = ..count..
    ),
    stat = "count",
    position = position_stack(vjust = 0.5),
    color = "black",
    size = 5,
    fontface = "bold"
  ) +
  scale_fill_brewer(palette = "Set2") +
  labs(
    title = "Répartition des individus selon leur statut d'emploi",
    fill = "Statut d'emploi",
    x = NULL,
    y = NULL
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
    axis.text = element_blank(),
    panel.grid = element_blank()
  )

p <- p + theme(
  plot.margin = margin(2, 2, 2, 2, unit = "cm")  # marges haut, droite, bas, gauche
)

# Export du graphique au format PNG
ggsave("statut_emploi.png", plot = p, width = 8, height = 8, dpi = 300)




# Création du graphique sans les pourcentages à l’intérieur des barres
p <- ggplot(individus, aes(x = niveau_educatif_diplome, fill = statut_emploi)) +
  geom_bar(position = "fill", width = 0.8, color = "white") +  # Bordure blanche pour la lisibilité
  coord_flip() +
  scale_y_continuous(labels = percent_format(), expand = c(0, 0)) +
  scale_fill_viridis_d(option = "D", direction = -1) +
  labs(
    title = "Statut d’emploi par niveau d’éducation",
    subtitle = "Proportions en pourcentage",
    x = "Niveau d’éducation",
    y = "Pourcentage",
    fill = "Statut emploi"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5),
    legend.position = "top",
    panel.grid.major.y = element_blank()
  )

# Sauvegarde du graphique
ggsave("statut_emploi_par_niveau.png", plot = p, width = 10, height = 6, dpi = 300)





p <- individus_csp %>%
  filter(!is.na(categorie_socioprofessionnelle), !is.na(niveau_educatif_diplome)) %>%
  ggplot(aes(x = fct_rev(niveau_educatif_diplome), fill = categorie_socioprofessionnelle)) +
  geom_bar(position = "fill", width = 0.8) +
  coord_flip() +
  scale_y_continuous(labels = percent_format(), expand = c(0, 0)) +
  scale_fill_viridis_d(option = "plasma", end = 0.9) +
  labs(
    title = "Répartition des CSP par niveau d’éducation",
    subtitle = "Proportions en pourcentage",
    x = "Niveau d’éducation",
    y = "Pourcentage",
    fill = "Catégorie socio-pro"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    legend.position = "top",
    legend.box = "horizontal",
    legend.text = element_text(size = 8)
  ) +
  guides(fill = guide_legend(nrow = 2, byrow = TRUE))

# Sauvegarde du graphique
ggsave("repartition_CSP_par_niveau.png", plot = p, width = 10, height = 6, dpi = 300)




# Test du chi² sur tableau croisé
tab_chi2 <- table(individus$niveau_educatif_diplome, individus$statut_emploi)
chisq.test(tab_chi2)


chisq.test(tab_chi2)$expected



# Résidus standardisés
chisq.test(tab_chi2)$stdres

# Regroupement simplifié
individus <- individus %>%
  mutate(niveau_simplifie = case_when(
    niveau_educatif_diplome == "Jamais scolarisé" ~ "Jamais scolarisé",
    niveau_educatif_diplome %in% c("Primaire sans diplôme", "Primaire diplômé") ~ "Primaire",
    niveau_educatif_diplome %in% c("Secondaire sans diplôme", "Secondaire diplômé") ~ "Secondaire",
    niveau_educatif_diplome == "Supérieur" ~ "Supérieur",
    TRUE ~ NA_character_
  ))

# Nouveau test chi²
tab_chi2_simplifie <- table(individus$niveau_simplifie, individus$statut_emploi)
chisq.test(tab_chi2_simplifie)

# Test du chi² sur le tableau simplifié
test_chi2_simplifie <- chisq.test(tab_chi2_simplifie)

# Résidus standardisés
stdres_simplifie <- test_chi2_simplifie$stdres
print(stdres_simplifie)


# Répartition du statut d'emploi selon le niveau d'éducation.

p <- individus %>%
  filter(!is.na(niveau_simplifie)) %>%
  count(niveau_simplifie, statut_emploi) %>%
  group_by(niveau_simplifie) %>%
  mutate(pourcentage = n / sum(n)) %>%
  ggplot(aes(x = niveau_simplifie, y = pourcentage, fill = statut_emploi)) +
  geom_bar(stat = "identity", position = "fill") +
  scale_y_continuous(labels = scales::percent_format()) +
  scale_fill_brewer(palette = "Set2") +
  labs(
    title = "Répartition du statut d'emploi selon le niveau d'éducation",
    x = "Niveau d'éducation (regroupé)",
    y = "Proportion (%)",
    fill = "Statut d'emploi"
  ) +
  theme_minimal(base_size = 13)

# Sauvegarde en PNG
ggsave("repartition_emploi_education.png", 
       plot = p,
       device = "png",
       width = 10, 
       height = 6,
       dpi = 300)
# Evaluons maintenant la force de la relation

install.packages("lsr")
library(lsr)

# V de Cramer
cramersV(tab_chi2_simplifie)















# Test du chi² : niveau d’éducation vs catégorie socio-pro
tab_educ_csp <- table(individus$niveau_simplifie, individus$categorie_socioprofessionnelle)

chi2_educ_csp <- chisq.test(tab_educ_csp)
chi2_educ_csp

# Résidus standardisés
chi2_educ_csp$stdres

# Visualisation

# On crée une table transformée en data.frame
df_csp <- as.data.frame(tab_educ_csp)
colnames(df_csp) <- c("Niveau", "CSP", "Effectif")

# Graphe en barres proportionnelles
q <- ggplot(df_csp, aes(x = Niveau, y = Effectif, fill = CSP)) +
    geom_bar(position = "fill", stat = "identity") +
    scale_y_continuous(labels = percent) +
    labs(
      title = "Répartition relative des catégories socioprofessionnelles selon le niveau d’éducation",
      x = "Niveau d'éducation simplifié",
      y = "Proportion",
      fill = "Catégorie socio-professionnelle"
    ) +
    theme_minimal()

ggsave("repartition_categorie_socio_education.png", 
       plot = q,
       device = "png",
       width = 10, 
       height = 6,
       dpi = 300)

# Force de l'association
install.packages("rcompanion")
library(rcompanion)
cramerV(tab_educ_csp)


##################################################FIN#####################################################################################

